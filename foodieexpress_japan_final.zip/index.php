<?php include("includes/db.php"); session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🍣 FoodieExpress Japan</title>
<style>
body{margin:0;font-family:'Poppins',sans-serif;background:#fff0f5;}
header{background:#ffb6c1;padding:20px;text-align:center;color:white;font-size:26px;font-weight:bold;}
.categories{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;max-width:900px;margin:30px auto;}
.category{background:white;border-radius:8px;overflow:hidden;text-align:center;box-shadow:0 4px 8px rgba(0,0,0,0.2);}
.category img{width:100%;height:120px;object-fit:cover;}
.category a{display:block;padding:10px;background:#ff69b4;color:white;text-decoration:none;font-weight:bold;}
.category a:hover{background:#ff1493;}
</style>
</head>
<body>
<header>🍣 Welcome to FoodieExpress Japan</header>
<div class="categories">
<div class="category"><img src="images/tamago_kake_gohan.jpg"><a href="part3_menu_cart/menu.php?category=breakfast">Asagohan (Breakfast)</a></div>
<div class="category"><img src="images/tamago_sando.jpg"><a href="part3_menu_cart/menu.php?category=brunch">Buranchi (Brunch)</a></div>
<div class="category"><img src="images/chicken_katsu_curry.jpg"><a href="part3_menu_cart/menu.php?category=lunch">Hirugohan (Lunch)</a></div>
<div class="category"><img src="images/sushi_platter.jpg"><a href="part3_menu_cart/menu.php?category=dinner">Bangohan (Dinner)</a></div>
<div class="category"><img src="images/mochi.jpg"><a href="part3_menu_cart/menu.php?category=dessert">Dezāto (Dessert)</a></div>
</div>
</body></html>